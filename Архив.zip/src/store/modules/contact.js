export default {
    namespaced: true,
    state: {
        params: [
            
        ]
    },
    getters: {

    },
    mutations: {

    },
    actions: {
        
    }
}