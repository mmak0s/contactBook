<template>
    <div>
        <h3>Sorry, that page is existing.</h3> <br>
        <router-link :to="{name: 'contacts'}">Return to contacts</router-link>
    </div>
</template>

<script>
export default {
    
}
</script>